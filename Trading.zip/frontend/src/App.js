import logo from './logo.svg';
import './App.css';
import Trading from './pages/trading/index'
import TradingViewWidget from './components/TradingViewChart';
function App() {
  return (
    <div className="App">
      <Trading />
    </div>
  );
}

export default App;
