import React, { useState, useEffect} from 'react';

const EntryMarketCell = ({entry, market}) => {
    return (
        <div>
            
        </div>
    )
}

export default EntryMarketCell;